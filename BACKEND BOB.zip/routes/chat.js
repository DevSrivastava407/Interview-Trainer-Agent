const express = require('express');
const router = express.Router();
const axios = require('axios');
const auth = require('../middleware/auth');

// ── WatsonX Orchestrate config ────────────────────────────────────────────────
// These can also be set in .env — process.env values take priority.
const WXO_HOST          = process.env.WXO_HOST           || 'https://eu-gb.watson-orchestrate.cloud.ibm.com';
const WXO_AGENT_ID      = process.env.WXO_AGENT_ID       || '9e1837dd-51f2-421a-88cb-20b49978d280';
const IBM_API_KEY       = process.env.IBM_API_KEY         || 'HpBJa9Pjyfybdejiq_k7hkqyrflHNmaca1oste5ypQ5S';
const IAM_TOKEN_URL     = 'https://iam.cloud.ibm.com/identity/token';

// ── IAM token cache ───────────────────────────────────────────────────────────
let _cachedToken   = null;
let _tokenExpireAt = 0;

async function getIAMToken() {
  const now = Date.now();
  if (_cachedToken && now < _tokenExpireAt) return _cachedToken;

  const params = new URLSearchParams();
  params.append('grant_type', 'urn:ibm:params:oauth:grant-type:apikey');
  params.append('apikey', IBM_API_KEY);

  const res = await axios.post(IAM_TOKEN_URL, params, {
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    timeout: 10000,
  });

  _cachedToken   = res.data.access_token;
  // IBM tokens last 3600 s — refresh 5 min early
  _tokenExpireAt = now + (res.data.expires_in - 300) * 1000;
  return _cachedToken;
}

// ── WatsonX Orchestrate session-less chat ─────────────────────────────────────
// Uses the stateless /v1/chat endpoint so we never need to manage sessions.
async function askOrchestrate(userMessage) {
  const token = await getIAMToken();

  const url = `${WXO_HOST}/v1/chat`;

  const payload = {
    agent_id: WXO_AGENT_ID,
    input: {
      message_type: 'text',
      text: userMessage,
    },
  };

  const res = await axios.post(url, payload, {
    headers: {
      Authorization: `Bearer ${token}`,
      'Content-Type': 'application/json',
    },
    timeout: 30000,
  });

  // Extract plain text reply — handle both possible response shapes
  const output = res.data?.output;
  if (output?.generic?.length) {
    return output.generic.map(g => g.text || '').join('\n').trim();
  }
  if (output?.text) return output.text.trim();
  if (typeof res.data?.reply === 'string') return res.data.reply.trim();

  return null;
}

// ── Knowledge base (fast local answers for common questions) ──────────────────
const KB = [
  {
    patterns: ['tell me about yourself', 'introduce yourself', 'about yourself', 'who are you'],
    answer: `**How to answer "Tell me about yourself"**

Use the **Present → Past → Future** framework (keep it to ~90 seconds):

1. **Present** – Your current role/situation and what you do day-to-day.
2. **Past** – Key experience or achievements that led you here.
3. **Future** – Why this specific role excites you.

**Example structure:**
> "I'm currently a [role] with X years of experience in [domain]. Over the past few years I've [key achievement]. I'm now looking to [next step] because [genuine reason this role excites you]."

**Tips:**
- Stay professional — this isn't a life story.
- Tailor it to the job description every time.
- Practise out loud until it sounds natural, not rehearsed.`,
  },
  {
    patterns: ['star method', 'star technique', 'situation task action result', 'star format', 'star answer'],
    answer: `**The STAR Method — a step-by-step guide**

STAR stands for **Situation → Task → Action → Result**. Use it for any behavioural question ("Tell me about a time when…").

| Step | What to cover | Rough time |
|------|--------------|-----------|
| **Situation** | Set the scene briefly — context, project, team size | ~10 % |
| **Task** | Your specific responsibility in that situation | ~10 % |
| **Action** | Exactly what YOU did (use "I", not "we") | ~60 % |
| **Result** | Measurable outcome — numbers, percentages, qualitative wins | ~20 % |

**Example:**
> *"Our deployment pipeline was taking 45 minutes (S). My task was to cut it to under 10 minutes (T). I introduced parallel test execution and Docker layer caching (A). This reduced build time by 78% and saved the team ~2 hours per day (R)."*

**Pro tips:**
- Prepare 5–6 STAR stories that can flex across many different questions.
- Always quantify the result if possible.
- Keep the whole answer under 2 minutes.`,
  },
  {
    patterns: ['behavioural interview', 'behavioral interview', 'behavioural questions', 'behavioral questions', 'common behavioural', 'common behavioral'],
    answer: `**Most Common Behavioural Interview Questions**

These all follow the "Tell me about a time when…" format. Prepare a STAR story for each category:

**Teamwork & Collaboration**
- Tell me about a time you worked in a difficult team.
- Describe a situation where you had to rely on others to achieve a goal.

**Leadership & Initiative**
- Tell me about a time you led a project without formal authority.
- Describe a time you spotted a problem and fixed it proactively.

**Conflict & Communication**
- Tell me about a disagreement with a colleague. How did you resolve it?
- Describe a time you had to deliver difficult feedback.

**Problem-solving & Pressure**
- Tell me about the most challenging problem you've solved.
- Describe a time you missed a deadline. What did you do?

**Adaptability & Learning**
- Tell me about a time you had to learn something quickly.
- Describe a major change at work and how you handled it.

**Achievement**
- What's your proudest professional accomplishment?
- Tell me about a time you exceeded expectations.

**Preparation tip:** Build a "story bank" of 6–8 strong examples. Each story should be usable for multiple questions.`,
  },
  {
    patterns: ['questions to ask', 'ask the interviewer', 'questions for interviewer', 'what to ask', 'end of interview questions'],
    answer: `**Great Questions to Ask Your Interviewer**

Asking good questions shows curiosity and preparation.

**About the role:**
- "What does success look like in this role after 90 days?"
- "What are the biggest challenges the person in this role will face?"
- "How does this role interact with other teams day-to-day?"

**About the team:**
- "Can you tell me about the team I'd be working with?"
- "What's the team's biggest priority right now?"

**About growth:**
- "What does a typical career progression look like for this role?"
- "What learning and development opportunities are available?"

**About next steps:**
- "What does the rest of the hiring process look like?"
- "Is there anything about my background that gives you pause?"

**Tip:** Prepare 4–5 questions. Some may be answered during the interview, so having extras is smart.`,
  },
  {
    patterns: ['salary', 'negotiate salary', 'salary negotiation', 'pay negotiation', 'compensation', 'salary offer'],
    answer: `**How to Negotiate Salary After a Job Offer**

Negotiation is expected — most employers leave room.

**1. Do your research first**
Use Glassdoor, LinkedIn Salary, or Levels.fyi to find the market range for your role, level, and location.

**2. Let them go first when possible**
> "I'd love to understand the full scope before discussing numbers. What's the budgeted range for this role?"

**3. Counter confidently**
> "I'm really excited about this offer. Based on my research and [X years of experience / specific skill], I was expecting something closer to [£X]. Is there flexibility?"

**4. Negotiate the full package**
If base salary is fixed, negotiate: sign-on bonus, extra PTO, remote work, equity, start date.

**Key rule:** Stay calm, be specific, and back your ask with data.`,
  },
  {
    patterns: ['calm', 'nervous', 'anxiety', 'stressed', 'technical interview tips', 'staying calm', 'interview anxiety'],
    answer: `**Tips for Staying Calm During a Technical Interview**

**Before the interview:**
- Practice out loud with mock interviews.
- Sleep well the night before — fatigue amplifies anxiety.
- Do a warm-up: solve 1–2 easy problems the morning of the interview.

**During the interview:**
- **Think out loud.** Interviewers want to see your process, not just the answer.
- **Clarify before coding.** Ask 2–3 clarifying questions — it shows maturity.
- **It's okay to pause.** Say "Give me a moment to think through this."
- **Start with brute force.** Get something working first, then optimise.

**Mindset shifts:**
- Treat it as a conversation, not an exam.
- The interviewer wants you to succeed — they're not adversaries.`,
  },
  {
    patterns: ['weakness', 'greatest weakness', 'areas for improvement', 'what are your weaknesses'],
    answer: `**How to Answer "What's Your Greatest Weakness?"**

Interviewers want self-awareness and a growth mindset.

**The formula:**
> Real weakness + What you're actively doing about it + Evidence of improvement

**Good examples:**
- *"I used to struggle with delegating tasks. I've been working on this by setting clear expectations and doing regular check-ins. My last project ran much smoother as a result."*
- *"Public speaking used to make me anxious. I joined a Toastmasters club six months ago and have since presented at two team all-hands."*

**What to avoid:**
- Fake weaknesses disguised as strengths ("I'm a perfectionist").
- Weaknesses that are core to the job.`,
  },
  {
    patterns: ['strength', 'greatest strength', 'what are your strengths', 'key strengths'],
    answer: `**How to Answer "What Are Your Greatest Strengths?"**

Pick 2–3 strengths directly relevant to the job.

**The formula:**
> Name the strength → Give a concrete example → State the result

**Strong examples:**
- *"Problem-solving under pressure: I diagnosed a critical production bug at 2am, identified it as a database deadlock within 20 minutes, and had it patched before customers were impacted."*
- *"Cross-team communication: I built a shared dashboard used by 4 departments that cut weekly status meetings by half."*

**Tip:** Read the job description carefully. Mirror their language.`,
  },
  {
    patterns: ['why do you want', 'why this company', 'why this role', 'why do you want to work here', 'why are you interested'],
    answer: `**How to Answer "Why Do You Want This Job?"**

**Three things to cover:**
1. **The role** — specific aspects that excite you technically or professionally.
2. **The company** — something concrete: mission, product, culture, recent work.
3. **The fit** — how your skills and goals align with what they need.

**Example:**
> "I'm drawn to this role because it combines [X and Y], which are exactly the areas I've been building expertise in. I've followed [Company] for a while — specifically, your approach to [product/value/initiative] stands out. And longer term, I want to grow into [career goal], which this role is a clear step toward."

**Rule:** Never say "for the salary" or "it seemed like a good fit" — show you chose them specifically.`,
  },
  {
    patterns: ['resume', 'cv', 'resume tips', 'cv tips', 'write a resume', 'improve resume'],
    answer: `**Resume / CV Tips for Interview Success**

**Format:**
- 1 page for < 10 years experience; 2 pages max for senior roles.
- Reverse chronological order (most recent first).
- Clean fonts: Calibri, Arial, or Garamond at 10–12pt.

**Content:**
- Lead each bullet with a strong action verb: *Built, Reduced, Led, Designed, Shipped*.
- Follow the **XYZ formula:** "Accomplished [X] as measured by [Y] by doing [Z]."
- Quantify everything: "Improved API response time by 40%", "Managed a team of 8".
- Tailor your resume for each job — mirror keywords from the job description.

**ATS tip:** Use plain text formatting. Fancy tables and columns often break applicant tracking systems.`,
  },
  {
    patterns: ['how to prepare', 'prepare for interview', 'interview preparation', 'interview prep', 'getting ready for interview'],
    answer: `**Complete Interview Preparation Checklist**

**1 Week Before:**
- Research the company deeply (products, mission, financials, recent news).
- Re-read the job description — identify 5 key themes.
- Prepare your top 5–6 STAR stories.
- Prepare 5 smart questions to ask.

**2–3 Days Before:**
- Practice answering common questions out loud (record yourself).
- Do a mock interview with a friend or tool like Pramp.
- Review your resume — know every line.

**Day Before:**
- Confirm the time, location, and format (video/phone/in-person).
- Test tech (camera, mic, internet for video calls).
- Sleep 7–8 hours.

**Day Of:**
- Eat a proper meal beforehand.
- Arrive / log in 10–15 minutes early.
- Take a breath — you've prepared, trust the work.

**After the interview:**
- Send a thank-you email within 24 hours.`,
  },
  {
    patterns: ['remote interview', 'video interview', 'online interview', 'zoom interview', 'teams interview'],
    answer: `**Tips for Remote / Video Interviews**

**Technical setup (day before):**
- Test your camera, microphone, and internet speed.
- Test the video platform (Zoom, Teams, Google Meet) with a friend.
- Have a backup plan: phone number of your interviewer in case tech fails.

**Environment:**
- Clean, neutral background or professional virtual one.
- Good lighting — natural light from the front works best.
- Quiet room, phone on silent, notifications off.

**During the call:**
- Look into the camera (not the screen) when speaking — it reads as eye contact.
- Sit slightly forward, upright — good posture conveys confidence.
- Pause slightly before answering — remote audio has small delays.`,
  },
];

// ── Matcher (local KB first) ───────────────────────────────────────────────────
function findLocalAnswer(message) {
  const lower = message.toLowerCase();
  let best = null;
  let bestScore = 0;

  for (const entry of KB) {
    for (const pattern of entry.patterns) {
      const words = pattern.split(' ');
      const matches = words.filter(w => lower.includes(w)).length;
      const score = matches / words.length;
      if (score > bestScore) {
        bestScore = score;
        best = entry;
      }
    }
  }

  if (best && bestScore >= 0.5) return best.answer;
  return null;
}

// ── POST /api/chat ─────────────────────────────────────────────────────────────
router.post('/', auth, async (req, res) => {
  const { message } = req.body;
  if (!message || !message.trim()) {
    return res.status(400).json({ message: 'Message is required.' });
  }

  const userText = message.trim();

  // 1. Try local KB first (instant, no network needed)
  const localAnswer = findLocalAnswer(userText);
  if (localAnswer) {
    return res.json({ reply: localAnswer, source: 'kb' });
  }

  // 2. Anything outside the KB → direct user to the WXO AI panel on the page.
  //    The IBM WatsonX Orchestrate embed widget handles unrestricted AI questions.
  return res.json({
    reply: `I don't have a built-in answer for that specific question.\n\n**Use the IBM WatsonX Orchestrate panel below ↓** — it's our full AI Interview Agent that can answer *any* question: career advice, mock interview practice, CV feedback, coding questions, industry-specific tips, and much more.\n\nOr try asking about one of these topics:\n- **Tell me about yourself**\n- **STAR method**\n- **Behavioural interview questions**\n- **Questions to ask your interviewer**\n- **Salary negotiation**\n- **Staying calm in interviews**\n- **Strengths & weaknesses**\n- **Resume / CV tips**\n- **Interview preparation checklist**`,
    source: 'redirect',
  });
});

module.exports = router;
