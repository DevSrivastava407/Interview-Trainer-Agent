const express = require('express');
const router = express.Router();
const { v4: uuidv4 } = require('uuid');
const fs = require('fs');
const path = require('path');
const auth = require('../middleware/auth');
const multer = require('multer');

const sessionsFile = path.join(__dirname, '../data/sessions.json');

const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, path.join(__dirname, '../uploads')),
  filename: (req, file, cb) => cb(null, `${Date.now()}-${file.originalname}`)
});
const upload = multer({ storage, limits: { fileSize: 5 * 1024 * 1024 } });

const getSessions = () => {
  if (!fs.existsSync(sessionsFile)) return [];
  try { return JSON.parse(fs.readFileSync(sessionsFile, 'utf8')); } catch { return []; }
};

const saveSessions = (sessions) => {
  fs.writeFileSync(sessionsFile, JSON.stringify(sessions, null, 2));
};

// Generate interview questions and tips based on role/experience/skills
const generateInterviewContent = (jobRole, experience, skills) => {
  const skillList = skills.split(',').map(s => s.trim()).filter(Boolean);
  const expYears = parseInt(experience) || 0;
  const level = expYears === 0 ? 'entry-level' : expYears <= 3 ? 'junior' : expYears <= 7 ? 'mid-level' : 'senior';
  const topSkills = skillList.slice(0, 3).join(', ') || 'relevant skills';

  const questions = [
    {
      question: `Tell me about yourself and your background as a ${jobRole}.`,
      modelAnswer: `I am a ${level} ${jobRole} with ${experience} years of experience. My core skills include ${topSkills}. I am passionate about delivering high-quality work and continuously growing my expertise. In my previous roles, I have successfully contributed to impactful projects that align with this position.`,
      tip: 'Keep it professional and structured. Focus on relevant experience. Aim for 90–120 seconds. End by connecting your background to this specific role.'
    },
    {
      question: `What are your greatest strengths as a ${jobRole}?`,
      modelAnswer: `My key strengths include ${skillList.join(', ') || 'strong technical and soft skills'}. I bring a results-oriented mindset and collaborative approach. Specifically, my proficiency in ${skillList[0] || 'core competencies'} has enabled me to consistently deliver high-impact outcomes in fast-paced environments.`,
      tip: 'Support each strength with a concrete example. Use the STAR method: Situation, Task, Action, Result. Choose strengths relevant to the job description.'
    },
    {
      question: `Describe a challenging project you worked on as a ${jobRole}.`,
      modelAnswer: `In one of my previous roles, I led a complex initiative that required deep expertise in ${skillList[0] || 'my domain'}. The challenge involved ${expYears > 3 ? 'coordinating cross-functional teams and managing competing priorities' : 'rapidly acquiring new skills and delivering under tight deadlines'}. I applied ${skillList.slice(0, 2).join(' and ') || 'systematic problem-solving'} to resolve key bottlenecks and delivered the project on time, resulting in measurable improvements for the team.`,
      tip: 'Use STAR format. Quantify your impact with numbers or metrics where possible (e.g., "reduced processing time by 30%"). Focus on YOUR specific contribution.'
    },
    {
      question: `How do you stay current with the latest trends and technologies in the ${jobRole} field?`,
      modelAnswer: `I actively follow industry publications, attend conferences, and participate in professional communities. For ${jobRole} specifically, I track developments in ${skillList[0] || 'core domain areas'} through blogs, podcasts, and online courses. I also apply new knowledge through personal projects and experimentation.`,
      tip: 'Name specific resources: journals, communities, or certifications. This shows genuine passion and initiative beyond the day job.'
    },
    {
      question: `How do you handle tight deadlines and high-pressure situations?`,
      modelAnswer: `I stay calm by breaking large problems into smaller, manageable tasks and prioritising by impact. I communicate proactively with stakeholders about trade-offs and timelines. My ${level} experience has built resilience; for example, I once delivered a critical ${jobRole} deliverable within 48 hours by focusing on essentials and deferring non-critical items.`,
      tip: 'Demonstrate time management, communication, and composure. A brief real example is far more persuasive than abstract claims.'
    },
    {
      question: `Where do you see yourself professionally in the next 3–5 years?`,
      modelAnswer: `I aim to deepen my expertise in ${skillList[0] || 'my core domain'} while expanding into ${skillList[1] || 'adjacent areas'}. ${expYears >= 5 ? 'I aspire to take on a leadership or senior advisory role where I can mentor others and drive strategic decisions.' : 'I want to grow into a senior contributor role, taking on greater responsibility and ownership of end-to-end projects.'} I see this company's mission as an exciting environment for that growth.`,
      tip: "Align your ambitions with the company's direction. Show initiative without seeming impatient for promotion. Research the company's growth plans beforehand."
    },
    {
      question: `Why are you interested in this ${jobRole} position at our company?`,
      modelAnswer: `This role directly aligns with my background in ${topSkills}. I am particularly drawn to the opportunity to work on impactful challenges in this domain. The company's reputation for innovation and the calibre of the team make this an exciting next step. I am confident I can add immediate value while continuing to grow professionally here.`,
      tip: 'Always research the company before the interview. Reference specific products, values, or recent news. Generic answers are easily spotted — personalise your response.'
    }
  ];

  const tips = [
    `Research the company thoroughly — understand their products, values, and recent news before your ${jobRole} interview.`,
    `Prepare 4–5 STAR-method examples from your past experience that showcase your ${skillList[0] || 'key skills'}.`,
    `Practice speaking your answers aloud. Recording yourself helps identify filler words and pacing issues.`,
    `Prepare 3–4 thoughtful questions to ask your interviewers — it signals genuine interest and engagement.`,
    `Review your resume line by line; be ready to discuss every project, role, and achievement listed.`,
    `For ${level} roles, ${expYears <= 2 ? 'emphasise your learning agility, enthusiasm, and growth trajectory.' : 'showcase your proven track record and ability to own complex deliverables.'}`,
    `Send a thank-you note within 24 hours of the interview — it reinforces your enthusiasm and professionalism.`
  ];

  return { questions, tips };
};

// POST /api/sessions — Create new interview prep session
router.post('/', auth, upload.single('resume'), (req, res) => {
  try {
    const { jobRole, experience, skills } = req.body;
    if (!jobRole || !skills)
      return res.status(400).json({ message: 'Job role and skills are required' });

    const content = generateInterviewContent(jobRole, experience || '0', skills);
    const session = {
      id: uuidv4(),
      userId: req.user.id,
      jobRole,
      experience: experience || '0',
      skills,
      resumeFile: req.file ? req.file.filename : null,
      questions: content.questions,
      tips: content.tips,
      createdAt: new Date().toISOString()
    };

    const sessions = getSessions();
    sessions.push(session);
    saveSessions(sessions);

    res.status(201).json(session);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Server error' });
  }
});

// GET /api/sessions — Get all sessions for authenticated user
router.get('/', auth, (req, res) => {
  const sessions = getSessions();
  const userSessions = sessions
    .filter(s => s.userId === req.user.id)
    .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
  res.json(userSessions);
});

// GET /api/sessions/:id — Get single session
router.get('/:id', auth, (req, res) => {
  const sessions = getSessions();
  const session = sessions.find(s => s.id === req.params.id && s.userId === req.user.id);
  if (!session) return res.status(404).json({ message: 'Session not found' });
  res.json(session);
});

// DELETE /api/sessions/:id — Delete session
router.delete('/:id', auth, (req, res) => {
  let sessions = getSessions();
  const index = sessions.findIndex(s => s.id === req.params.id && s.userId === req.user.id);
  if (index === -1) return res.status(404).json({ message: 'Session not found' });
  sessions.splice(index, 1);
  saveSessions(sessions);
  res.json({ message: 'Session deleted' });
});

module.exports = router;
