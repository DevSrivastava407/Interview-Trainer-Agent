import React, { useState } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { useTheme } from '../context/ThemeContext';
import {
  LayoutDashboard, FileText, History, Bot,
  LogOut, Sun, Moon, Menu, X, BrainCircuit
} from 'lucide-react';
import './Navbar.css';

const navLinks = [
  { path: '/dashboard',    label: 'Dashboard',   icon: LayoutDashboard },
  { path: '/prepare',      label: 'Prepare',     icon: FileText },
  { path: '/history',      label: 'History',     icon: History },
  { path: '/ai-assistant', label: 'AI Assistant',icon: Bot },
];

export default function Navbar() {
  const { user, logout } = useAuth();
  const { theme, toggleTheme } = useTheme();
  const navigate = useNavigate();
  const { pathname } = useLocation();
  const [mobileOpen, setMobileOpen] = useState(false);

  const handleLogout = () => { logout(); navigate('/login'); };

  return (
    <nav className="navbar">
      <div className="navbar-inner">
        {/* Brand */}
        <Link to="/dashboard" className="navbar-brand">
          <div className="brand-icon"><BrainCircuit size={18} /></div>
          <span className="brand-label">Interview Trainer</span>
        </Link>
        <div className="navbar-divider" />

        {/* Desktop links */}
        <ul className="navbar-links">
          {navLinks.map(({ path, label, icon: Icon }) => (
            <li key={path}>
              <Link
                to={path}
                className={`nav-link ${pathname === path ? 'active' : ''}`}
              >
                <Icon size={15} />
                {label}
              </Link>
            </li>
          ))}
        </ul>

        {/* Right actions */}
        <div className="navbar-actions">
          <button className="icon-btn" onClick={toggleTheme} title="Toggle theme" aria-label="Toggle theme">
            {theme === 'dark' ? <Sun size={18} /> : <Moon size={18} />}
          </button>
          <span className="user-chip">{user?.name?.charAt(0).toUpperCase()}</span>
          <button className="btn btn-sm btn-secondary" onClick={handleLogout}>
            <LogOut size={14} /> Logout
          </button>
          <button className="icon-btn mobile-toggle" onClick={() => setMobileOpen(o => !o)} aria-label="Toggle menu">
            {mobileOpen ? <X size={20} /> : <Menu size={20} />}
          </button>
        </div>
      </div>

      {/* Mobile drawer */}
      {mobileOpen && (
        <div className="mobile-menu">
          {navLinks.map(({ path, label, icon: Icon }) => (
            <Link
              key={path}
              to={path}
              className={`mobile-link ${pathname === path ? 'active' : ''}`}
              onClick={() => setMobileOpen(false)}
            >
              <Icon size={16} /> {label}
            </Link>
          ))}
          <button className="btn btn-sm btn-secondary" style={{ marginTop: 8 }} onClick={handleLogout}>
            <LogOut size={14} /> Logout
          </button>
        </div>
      )}
    </nav>
  );
}
