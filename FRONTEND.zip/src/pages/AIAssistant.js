import React, { useEffect, useState, useRef } from 'react';
import { Bot, Zap, MessageSquare, BookOpen, Info, Send, ExternalLink } from 'lucide-react';
import api from '../api/axios';
import './AIAssistant.css';

const SUGGESTIONS = [
  'How do I answer "Tell me about yourself"?',
  'What are the most common behavioural interview questions?',
  'How do I use the STAR method in my answers?',
  'What questions should I ask my interviewer?',
  'How do I negotiate salary after a job offer?',
  'Tips for staying calm during a technical interview?',
];

// ── Markdown renderer ──────────────────────────────────────────────────────────
function renderMarkdown(raw) {
  let text = raw
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;');

  text = text.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>');
  text = text.replace(/`([^`]+)`/g, '<code class="inline-code">$1</code>');
  text = text.replace(/^&gt;\s?(.+)$/gm, '<blockquote>$1</blockquote>');

  text = text.replace(/^\|(.+)\|$/gm, (_, row) => {
    const cells = row.split('|').map(c => c.trim());
    if (cells.every(c => /^[-: ]+$/.test(c))) return '';
    return '<tr>' + cells.map(c => `<td>${c}</td>`).join('') + '</tr>';
  });
  text = text.replace(/(<tr>[\s\S]*?<\/tr>\n?)+/g, m => `<table class="chat-table">${m}</table>`);

  text = text.replace(/^\d+\.\s+(.+)$/gm, '<li>$1</li>');
  text = text.replace(/(<li>[\s\S]*?<\/li>\n?)+/g, m => `<ol>${m}</ol>`);

  text = text.replace(/^[-•]\s+(.+)$/gm, '<li>$1</li>');
  text = text.replace(/(<li>[\s\S]*?<\/li>\n?)+/g, m => `<ul>${m}</ul>`);

  text = text.replace(/\n/g, '<br/>');
  return text;
}

// ── WatsonX Orchestrate web-chat embed ────────────────────────────────────────
// The WXO loader directly manipulates DOM nodes. To prevent a React
// "removeChild" crash we create a plain <div> imperatively, append it to
// the ref container, then point WXO at that node's id — React never touches
// that inner div so there is no DOM ownership conflict.
const WXO_HOST = 'https://eu-gb.watson-orchestrate.cloud.ibm.com';
const WXO_MOUNT_ID = 'wxo-inner-mount'; // owned by WXO, not React

function injectWXOChat(containerEl, onReady) {
  if (window._wxoChatInjected) { onReady && onReady(); return; }
  window._wxoChatInjected = true;

  // Create the inner mount node imperatively — outside React's reconciliation
  const mount = document.createElement('div');
  mount.id = WXO_MOUNT_ID;
  containerEl.appendChild(mount);

  window.wxOConfiguration = {
    orchestrationID: 'e3a4a8ae148e46ca88e20d0dda8a062c_c49d8a6a-b6d8-4443-a35e-df2606b0fc0c',
    hostURL: WXO_HOST,
    rootElementID: WXO_MOUNT_ID,
    deploymentPlatform: 'ibmcloud',
    crn: 'crn:v1:bluemix:public:watsonx-orchestrate:eu-gb:a/e3a4a8ae148e46ca88e20d0dda8a062c:c49d8a6a-b6d8-4443-a35e-df2606b0fc0c::',
    chatOptions: {
      agentId: '9e1837dd-51f2-421a-88cb-20b49978d280',
    },
  };

  const script = document.createElement('script');
  script.src = `${WXO_HOST}/wxochat/wxoLoader.js?embed=true`;
  script.addEventListener('load', () => {
    try {
      if (window.wxoLoader && typeof window.wxoLoader.init === 'function') {
        window.wxoLoader.init();
      }
    } catch (e) {
      console.warn('[WXO] init error:', e);
    }
    onReady && onReady();
  });
  script.onerror = () => {
    console.warn('[WXO] Failed to load WatsonX Orchestrate chat script.');
    onReady && onReady();
  };
  document.head.appendChild(script);
}

// ── Component ──────────────────────────────────────────────────────────────────
export default function AIAssistant() {
  const [messages, setMessages] = useState([
    {
      role: 'assistant',
      text: "Hi! I'm your AI Interview Coach. I can answer common interview questions instantly, and for anything else the **IBM WatsonX Orchestrate** panel below handles any question you have.",
    },
  ]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [wxoReady, setWxoReady] = useState(false);
  const messagesEndRef = useRef(null);
  // Ref for the React-rendered outer shell — WXO gets its own imperative div inside
  const wxoContainerRef = useRef(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  // Inject the WXO widget once, into an imperatively-created child node
  // so React never tries to reconcile or removeChild what WXO owns.
  useEffect(() => {
    if (!wxoContainerRef.current) return;
    injectWXOChat(wxoContainerRef.current, () => setWxoReady(true));
    // No cleanup — WXO script and its DOM are intentionally long-lived
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const sendMessage = async (text) => {
    const userText = (text !== undefined ? text : input).trim();
    if (!userText || loading) return;

    setInput('');
    setMessages(prev => [...prev, { role: 'user', text: userText }]);
    setLoading(true);

    try {
      const res = await api.post('/chat', { message: userText }, { timeout: 35000 });
      const reply = res.data?.reply || "I didn't receive a response. Please try again.";
      setMessages(prev => [...prev, { role: 'assistant', text: reply }]);
    } catch (err) {
      const errorText =
        err.response?.data?.message ||
        err.message ||
        'Something went wrong. Please try again in a moment.';
      setMessages(prev => [
        ...prev,
        { role: 'assistant', text: `⚠️ ${errorText}` },
      ]);
    } finally {
      setLoading(false);
    }
  };

  const handleKey = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  };

  return (
    <div className="ai-wrapper">
      {/* Page Header */}
      <div className="ai-header">
        <h1>AI Interview Assistant</h1>
        <p>Your intelligent interview coaching agent — powered by IBM WatsonX Orchestrate.</p>
        <div className="ai-features">
          <span className="ai-feat-chip"><Zap size={12} /> Real-time coaching</span>
          <span className="ai-feat-chip"><MessageSquare size={12} /> Natural conversation</span>
          <span className="ai-feat-chip"><BookOpen size={12} /> Expert interview tips</span>
        </div>
      </div>

      <div className="ai-layout">
        {/* Left — quick-answer chat */}
        <div className="chat-section">
          <div className="chat-section-header">
            <Bot size={18} style={{ color: 'var(--accent)' }} />
            <h2>Quick Answers</h2>
            <div className="chat-status">
              <span className="status-dot" />
              Active
            </div>
          </div>

          <div className="chat-messages">
            {messages.map((msg, i) => (
              <div key={i} className={`chat-bubble chat-bubble--${msg.role}`}>
                {msg.role === 'assistant' && <Bot size={14} className="bubble-icon" />}
                {msg.role === 'assistant' ? (
                  <span
                    className="bubble-text"
                    dangerouslySetInnerHTML={{ __html: renderMarkdown(msg.text) }}
                  />
                ) : (
                  <span className="bubble-text">{msg.text}</span>
                )}
              </div>
            ))}

            {loading && (
              <div className="chat-bubble chat-bubble--assistant">
                <Bot size={14} className="bubble-icon" />
                <span className="typing-dots">
                  <span /><span /><span />
                </span>
              </div>
            )}

            <div ref={messagesEndRef} />
          </div>

          <div className="chat-input-row">
            <textarea
              className="chat-input"
              rows={1}
              placeholder="Ask anything about your interview… (Enter to send)"
              value={input}
              onChange={e => setInput(e.target.value)}
              onKeyDown={handleKey}
              disabled={loading}
            />
            <button
              className="chat-send-btn"
              onClick={() => sendMessage()}
              disabled={loading || !input.trim()}
              title="Send (Enter)"
            >
              <Send size={16} />
            </button>
          </div>
        </div>

        {/* Right — sidebar */}
        <div className="ai-sidebar">
          <div className="sidebar-card">
            <h3><MessageSquare size={14} /> Suggested Prompts</h3>
            {SUGGESTIONS.map((s, i) => (
              <button
                key={i}
                className="suggestion-btn"
                onClick={() => sendMessage(s)}
                disabled={loading}
              >
                {s}
              </button>
            ))}
            <p style={{ fontSize: 11, color: 'var(--muted)', marginTop: 4 }}>
              Click a prompt to send it directly to the chat.
            </p>
          </div>

          <div className="sidebar-card">
            <h3><Info size={14} /> About This Agent</h3>
            <div className="info-row">
              <Bot size={14} />
              <span>Quick Answers uses a local knowledge base for instant interview tips.</span>
            </div>
            <div className="info-row">
              <Zap size={14} />
              <span>IBM WatsonX Orchestrate (below) answers <strong>any</strong> question you ask.</span>
            </div>
            <div className="info-row">
              <BookOpen size={14} />
              <span>Use the WXO chat panel for career advice, custom questions, and more.</span>
            </div>
          </div>
        </div>
      </div>

      {/* ── IBM WatsonX Orchestrate full AI chat panel ── */}
      <div className="wxo-section">
        <div className="wxo-section-header">
          <ExternalLink size={16} style={{ color: 'var(--accent)' }} />
          <h2>IBM WatsonX Orchestrate — Interview Agent</h2>
          <span className="wxo-badge">Powered by IBM AI</span>
        </div>
        <p className="wxo-desc">
          Ask <strong>any</strong> question here — career advice, mock interview questions, CV feedback,
          industry-specific tips, and more. This agent has no topic restrictions.
        </p>
        {/* Outer shell managed by React — WXO mounts its own div imperatively inside */}
        <div ref={wxoContainerRef} className="wxo-chat-root">
          {!wxoReady && (
            <div className="wxo-loading">
              <span className="typing-dots"><span /><span /><span /></span>
              <span style={{ marginLeft: 8, color: 'var(--muted)', fontSize: 13 }}>
                Loading IBM WatsonX Orchestrate…
              </span>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
