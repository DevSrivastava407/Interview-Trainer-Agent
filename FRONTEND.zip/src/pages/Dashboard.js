import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import api from '../api/axios';
import {
  BrainCircuit, FileText, History, Bot,
  TrendingUp, PlusCircle, Clock, ChevronRight
} from 'lucide-react';
import './Dashboard.css';

const StatCard = ({ icon: Icon, label, value, color }) => (
  <div className="stat-card">
    <div className="stat-icon" style={{ background: color + '22', color }}>
      <Icon size={22} />
    </div>
    <div>
      <div className="stat-value">{value}</div>
      <div className="stat-label">{label}</div>
    </div>
  </div>
);

export default function Dashboard() {
  const { user } = useAuth();
  const [sessions, setSessions] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.get('/sessions')
      .then(res => setSessions(res.data))
      .catch(() => {})
      .finally(() => setLoading(false));
  }, []);

  const recent = sessions.slice(0, 5);
  const roles = [...new Set(sessions.map(s => s.jobRole))].length;

  return (
    <div className="page-wrapper">
      <div className="dashboard-hero">
        <div>
          <h1>Welcome back, <span>{user?.name?.split(' ')[0]}</span>!</h1>
          <p>Ready to ace your next interview? Let's prepare.</p>
        </div>
        <Link to="/prepare" className="btn btn-lg" style={{ background: 'rgba(255,255,255,0.15)', color: '#fff', border: '1px solid rgba(255,255,255,0.3)' }}>
          <PlusCircle size={18} /> New Preparation
        </Link>
      </div>

      {/* Stats */}
      <div className="stats-grid">
        <StatCard icon={FileText}   label="Total Sessions"   value={sessions.length} color="#3b82d4" />
        <StatCard icon={TrendingUp} label="Roles Practiced"  value={roles}           color="#7c3aed" />
        <StatCard icon={Clock}      label="Questions Reviewed" value={sessions.reduce((a, s) => a + (s.questions?.length || 0), 0)} color="#16a34a" />
        <StatCard icon={Bot}        label="AI Chats Available" value="Unlimited"     color="#d97706" />
      </div>

      {/* Quick Actions */}
      <div className="section-title">Quick Actions</div>
      <div className="quick-actions">
        <Link to="/prepare" className="qa-card">
          <div className="qa-icon" style={{ background: '#dbeafe', color: '#1d4ed8' }}><FileText size={24} /></div>
          <div className="qa-label">Start Preparation</div>
          <div className="qa-sub">Generate questions & tips</div>
        </Link>
        <Link to="/ai-assistant" className="qa-card">
          <div className="qa-icon" style={{ background: '#ede9fe', color: '#6d28d9' }}><Bot size={24} /></div>
          <div className="qa-label">AI Interview Assistant</div>
          <div className="qa-sub">Chat with your AI coach</div>
        </Link>
        <Link to="/history" className="qa-card">
          <div className="qa-icon" style={{ background: '#dcfce7', color: '#15803d' }}><History size={24} /></div>
          <div className="qa-label">Session History</div>
          <div className="qa-sub">Review past sessions</div>
        </Link>
      </div>

      {/* Recent Sessions */}
      {sessions.length > 0 && (
        <>
          <div className="section-header">
            <div className="section-title" style={{ marginBottom: 0 }}>Recent Sessions</div>
            <Link to="/history" className="see-all">See all <ChevronRight size={14} /></Link>
          </div>
          <div className="recent-list">
            {loading ? (
              <div className="loading-text">Loading sessions…</div>
            ) : (
              recent.map(s => (
                <Link to={`/session/${s.id}`} key={s.id} className="recent-item">
                  <div className="recent-icon"><BrainCircuit size={18} /></div>
                  <div className="recent-info">
                    <div className="recent-role">{s.jobRole}</div>
                    <div className="recent-meta">
                      {s.questions?.length || 0} questions &nbsp;·&nbsp;
                      {new Date(s.createdAt).toLocaleDateString()}
                    </div>
                  </div>
                  <span className="badge badge-blue">{s.experience} yr{s.experience !== '1' ? 's' : ''}</span>
                  <ChevronRight size={16} className="recent-arrow" />
                </Link>
              ))
            )}
          </div>
        </>
      )}

      {sessions.length === 0 && !loading && (
        <div className="empty-state">
          <BrainCircuit size={48} style={{ color: 'var(--border)' }} />
          <h3>No sessions yet</h3>
          <p>Create your first interview preparation session to get started.</p>
          <Link to="/prepare" className="btn btn-primary">
            <PlusCircle size={16} /> Start Now
          </Link>
        </div>
      )}
    </div>
  );
}
