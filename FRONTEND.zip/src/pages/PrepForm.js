import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { toast } from 'react-toastify';
import api from '../api/axios';
import { BrainCircuit, Upload, Sparkles, FileCheck } from 'lucide-react';
import './PrepForm.css';

export default function PrepForm() {
  const navigate = useNavigate();
  const [form, setForm] = useState({ jobRole: '', experience: '', skills: '' });
  const [resume, setResume] = useState(null);
  const [loading, setLoading] = useState(false);

  const handle = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  const handleFile = (e) => {
    const file = e.target.files[0];
    if (file && file.size > 5 * 1024 * 1024) {
      toast.error('Resume must be under 5 MB.'); return;
    }
    setResume(file || null);
  };

  const submit = async (e) => {
    e.preventDefault();
    if (!form.jobRole.trim()) { toast.error('Please enter a job role.'); return; }
    if (!form.skills.trim())  { toast.error('Please enter at least one skill.'); return; }

    setLoading(true);
    try {
      const data = new FormData();
      data.append('jobRole', form.jobRole.trim());
      data.append('experience', form.experience || '0');
      data.append('skills', form.skills.trim());
      if (resume) data.append('resume', resume);

      const res = await api.post('/sessions', data, {
        headers: { 'Content-Type': 'multipart/form-data' }
      });
      toast.success('Interview prep session created!');
      navigate(`/session/${res.data.id}`);
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed to create session.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="prep-wrapper">
      <div className="prep-header">
        <h1>Interview Preparation</h1>
        <p>Fill in the details below. We'll generate tailored interview questions, model answers, and preparation tips.</p>
      </div>

      <form onSubmit={submit}>
        <div className="prep-card">
          <h2><BrainCircuit size={18} /> Role & Experience</h2>

          <div className="form-row">
            <div className="form-group">
              <label>Job Role *</label>
              <input
                className="form-control"
                name="jobRole"
                placeholder="e.g. Software Engineer"
                value={form.jobRole}
                onChange={handle}
                required
                autoFocus
              />
            </div>
            <div className="form-group">
              <label>Years of Experience</label>
              <input
                className="form-control"
                name="experience"
                type="number"
                min="0"
                max="40"
                placeholder="e.g. 3"
                value={form.experience}
                onChange={handle}
              />
            </div>
          </div>

          <div className="form-group">
            <label>Key Skills *</label>
            <input
              className="form-control"
              name="skills"
              placeholder="e.g. React, Node.js, Python, SQL (comma-separated)"
              value={form.skills}
              onChange={handle}
              required
            />
            <small style={{ color: 'var(--muted)', fontSize: 12 }}>
              Separate multiple skills with commas
            </small>
          </div>

          <div className="form-group">
            <label>Resume Upload <span style={{ color: 'var(--muted)', fontWeight: 400 }}>(optional — PDF, DOCX, max 5 MB)</span></label>
            <div className="file-upload">
              <label className="file-upload-label" htmlFor="resume-input">
                {resume ? (
                  <>
                    <FileCheck size={28} style={{ color: 'var(--success)' }} />
                    <span className="file-selected">{resume.name}</span>
                    <span className="file-upload-text">Click to change file</span>
                  </>
                ) : (
                  <>
                    <Upload size={28} style={{ color: 'var(--muted)' }} />
                    <span className="file-upload-text">Click to upload your resume</span>
                    <span style={{ fontSize: 11, color: 'var(--muted)' }}>PDF, DOC, DOCX up to 5 MB</span>
                  </>
                )}
              </label>
              <input id="resume-input" type="file" accept=".pdf,.doc,.docx" onChange={handleFile} />
            </div>
          </div>
        </div>

        <div className="prep-submit">
          <button
            type="submit"
            className="btn btn-primary btn-lg"
            disabled={loading}
          >
            <Sparkles size={18} />
            {loading ? 'Generating…' : 'Generate Interview Prep'}
          </button>
        </div>
      </form>
    </div>
  );
}
