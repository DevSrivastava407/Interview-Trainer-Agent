import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { toast } from 'react-toastify';
import { useAuth } from '../context/AuthContext';
import { BrainCircuit, UserPlus } from 'lucide-react';
import './Auth.css';

export default function Register() {
  const { register } = useAuth();
  const navigate = useNavigate();
  const [form, setForm] = useState({ name: '', email: '', password: '', confirm: '' });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handle = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  const submit = async (e) => {
    e.preventDefault();
    setError('');
    if (form.password !== form.confirm) { setError('Passwords do not match.'); return; }
    if (form.password.length < 6) { setError('Password must be at least 6 characters.'); return; }
    setLoading(true);
    try {
      await register(form.name, form.email, form.password);
      toast.success('Account created! Welcome aboard.');
      navigate('/dashboard');
    } catch (err) {
      setError(err.response?.data?.message || err.message || 'Registration failed. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="auth-wrapper">
      {/* Left branding panel */}
      <div className="auth-left">
        <div className="auth-left-logo"><BrainCircuit size={28} /></div>
        <h2>Start preparing smarter today</h2>
        <p>Join Interview Trainer and land your dream job with AI-powered coaching tailored to your profile.</p>
        <ul className="auth-bullet-list">
          <li>Free to get started</li>
          <li>Tailored to your job role & skills</li>
          <li>Downloadable PDF prep reports</li>
          <li>Chat with an IBM watsonx AI agent</li>
        </ul>
      </div>

      {/* Right form panel */}
      <div className="auth-right">
        <div className="auth-box">
          <div className="auth-header">
            <h1>Create account</h1>
            <p>Start your interview preparation journey.</p>
          </div>

          {error && <div className="error-msg">{error}</div>}

          <form onSubmit={submit}>
            <div className="form-group">
              <label>Full name</label>
              <input
                className="form-control"
                type="text"
                name="name"
                placeholder="Jane Smith"
                value={form.name}
                onChange={handle}
                required
                autoFocus
              />
            </div>
            <div className="form-group">
              <label>Email address</label>
              <input
                className="form-control"
                type="email"
                name="email"
                placeholder="you@example.com"
                value={form.email}
                onChange={handle}
                required
              />
            </div>
            <div className="form-group">
              <label>Password</label>
              <input
                className="form-control"
                type="password"
                name="password"
                placeholder="Min. 6 characters"
                value={form.password}
                onChange={handle}
                required
              />
            </div>
            <div className="form-group">
              <label>Confirm password</label>
              <input
                className="form-control"
                type="password"
                name="confirm"
                placeholder="Repeat password"
                value={form.confirm}
                onChange={handle}
                required
              />
            </div>
            <button
              type="submit"
              className="btn btn-primary btn-lg"
              style={{ width: '100%', marginTop: 8 }}
              disabled={loading}
            >
              <UserPlus size={16} />
              {loading ? 'Creating account…' : 'Create Account'}
            </button>
          </form>

          <div className="auth-footer">
            Already have an account? <Link to="/login">Sign in</Link>
          </div>
        </div>
      </div>
    </div>
  );
}
