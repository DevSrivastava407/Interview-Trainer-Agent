import React, { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { toast } from 'react-toastify';
import api from '../api/axios';
import {
  History, Search, Download, Eye, Trash2,
  BrainCircuit, PlusCircle, Clock, Briefcase
} from 'lucide-react';
import './SessionHistory.css';

export default function SessionHistory() {
  const navigate = useNavigate();
  const [sessions, setSessions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [downloading, setDownloading] = useState(null);

  useEffect(() => {
    api.get('/sessions')
      .then(res => setSessions(res.data))
      .catch(() => toast.error('Failed to load sessions.'))
      .finally(() => setLoading(false));
  }, []);

  const deleteSession = async (id) => {
    if (!window.confirm('Delete this session? This cannot be undone.')) return;
    try {
      await api.delete(`/sessions/${id}`);
      setSessions(s => s.filter(x => x.id !== id));
      toast.success('Session deleted.');
    } catch {
      toast.error('Failed to delete session.');
    }
  };

  const downloadPDF = async (session) => {
    setDownloading(session.id);
    try {
      const res = await api.get(`/reports/${session.id}`, { responseType: 'blob' });
      const url = URL.createObjectURL(new Blob([res.data], { type: 'application/pdf' }));
      const a = document.createElement('a');
      a.href = url;
      a.download = `interview-prep-${session.jobRole.replace(/\s+/g, '-')}.pdf`;
      a.click();
      URL.revokeObjectURL(url);
      toast.success('PDF downloaded!');
    } catch {
      toast.error('Download failed.');
    } finally {
      setDownloading(null);
    }
  };

  const filtered = sessions.filter(s =>
    s.jobRole.toLowerCase().includes(search.toLowerCase()) ||
    s.skills.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="history-wrapper">
      <div className="history-header">
        <div>
          <h1>Session History</h1>
          <p>{sessions.length} session{sessions.length !== 1 ? 's' : ''} saved</p>
        </div>
        <Link to="/prepare" className="btn btn-primary">
          <PlusCircle size={16} /> New Session
        </Link>
      </div>

      {sessions.length > 0 && (
        <div className="history-toolbar">
          <div style={{ position: 'relative', flex: 1, minWidth: 200 }}>
            <Search size={15} style={{ position: 'absolute', left: 11, top: '50%', transform: 'translateY(-50%)', color: 'var(--muted)' }} />
            <input
              className="history-search"
              style={{ paddingLeft: 34 }}
              placeholder="Search by role or skill…"
              value={search}
              onChange={e => setSearch(e.target.value)}
            />
          </div>
        </div>
      )}

      {loading && (
        <div style={{ textAlign: 'center', padding: '60px 0', color: 'var(--muted)' }}>
          Loading sessions…
        </div>
      )}

      {!loading && filtered.length === 0 && (
        <div className="empty-state" style={{ display:'flex', flexDirection:'column', alignItems:'center', gap:12, padding:'60px 20px', textAlign:'center' }}>
          <BrainCircuit size={48} style={{ color: 'var(--border)' }} />
          {sessions.length === 0 ? (
            <>
              <h3 style={{ fontSize:17, color:'var(--text)' }}>No sessions yet</h3>
              <p style={{ fontSize:14, color:'var(--muted)' }}>Create your first interview preparation session.</p>
              <Link to="/prepare" className="btn btn-primary"><PlusCircle size={16} /> Start Now</Link>
            </>
          ) : (
            <>
              <h3 style={{ fontSize:17, color:'var(--text)' }}>No results found</h3>
              <p style={{ fontSize:14, color:'var(--muted)' }}>Try a different search term.</p>
            </>
          )}
        </div>
      )}

      <div className="history-grid">
        {filtered.map(session => (
          <div key={session.id} className="history-card">
            <div className="hc-top">
              <div className="hc-role">{session.jobRole}</div>
              <div className="hc-date">{new Date(session.createdAt).toLocaleDateString()}</div>
            </div>
            <div className="hc-meta">
              <span className="badge badge-blue"><Briefcase size={10} style={{marginRight:3}} />{session.experience} yr</span>
              <span className="badge badge-purple">{session.questions?.length || 0} Qs</span>
              {session.resumeFile && <span className="badge badge-green">Resume</span>}
            </div>
            <div className="hc-skills" title={session.skills}>{session.skills}</div>
            <div className="hc-actions">
              <button
                className="btn btn-secondary btn-sm"
                onClick={() => downloadPDF(session)}
                disabled={downloading === session.id}
                title="Download PDF"
              >
                <Download size={13} />
                {downloading === session.id ? '…' : 'PDF'}
              </button>
              <button
                className="btn btn-secondary btn-sm"
                onClick={() => navigate(`/session/${session.id}`)}
                title="View session"
              >
                <Eye size={13} /> View
              </button>
              <button
                className="btn btn-danger btn-sm"
                onClick={() => deleteSession(session.id)}
                title="Delete session"
              >
                <Trash2 size={13} />
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
