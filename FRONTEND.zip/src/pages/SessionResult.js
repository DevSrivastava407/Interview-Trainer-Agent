import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { toast } from 'react-toastify';
import api from '../api/axios';
import {
  FileText, Download, ChevronDown, ChevronUp,
  Briefcase, Clock, Code2, Lightbulb, ArrowLeft
} from 'lucide-react';
import './SessionResult.css';

function QuestionCard({ q, index }) {
  const [open, setOpen] = useState(index === 0);
  return (
    <div className="q-card">
      <div className="q-header" onClick={() => setOpen(o => !o)}>
        <div className="q-num">{index + 1}</div>
        <div className="q-text">{q.question}</div>
        <span className={`q-toggle ${open ? 'open' : ''}`}>
          {open ? <ChevronUp size={18} /> : <ChevronDown size={18} />}
        </span>
      </div>
      {open && (
        <div className="q-body">
          <div className="q-section-label">Model Answer</div>
          <div className="q-answer">{q.modelAnswer}</div>
          <div className="q-tip">
            <Lightbulb size={15} style={{ flexShrink: 0, marginTop: 1 }} />
            {q.tip}
          </div>
        </div>
      )}
    </div>
  );
}

export default function SessionResult() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [session, setSession] = useState(null);
  const [loading, setLoading] = useState(true);
  const [downloading, setDownloading] = useState(false);

  useEffect(() => {
    api.get(`/sessions/${id}`)
      .then(res => setSession(res.data))
      .catch(() => { toast.error('Session not found.'); navigate('/history'); })
      .finally(() => setLoading(false));
  }, [id, navigate]);

  const downloadPDF = async () => {
    setDownloading(true);
    try {
      const res = await api.get(`/reports/${id}`, { responseType: 'blob' });
      const url = URL.createObjectURL(new Blob([res.data], { type: 'application/pdf' }));
      const a = document.createElement('a');
      a.href = url;
      a.download = `interview-prep-${session.jobRole.replace(/\s+/g, '-')}.pdf`;
      a.click();
      URL.revokeObjectURL(url);
      toast.success('PDF downloaded successfully!');
    } catch {
      toast.error('Failed to download PDF.');
    } finally {
      setDownloading(false);
    }
  };

  if (loading) return (
    <div className="result-wrapper">
      <div style={{ textAlign: 'center', padding: '60px 0', color: 'var(--muted)' }}>
        Loading session…
      </div>
    </div>
  );

  if (!session) return null;

  return (
    <div className="result-wrapper">
      {/* Top */}
      <div className="result-top">
        <div>
          <button className="btn btn-secondary btn-sm" onClick={() => navigate(-1)} style={{ marginBottom: 10 }}>
            <ArrowLeft size={14} /> Back
          </button>
          <div className="result-title">
            <h1>Interview Prep: {session.jobRole}</h1>
            <p>Generated on {new Date(session.createdAt).toLocaleDateString('en-GB', { day: 'numeric', month: 'long', year: 'numeric' })}</p>
          </div>
        </div>
        <div className="result-actions">
          <button className="btn btn-primary" onClick={downloadPDF} disabled={downloading}>
            <Download size={16} />
            {downloading ? 'Generating PDF…' : 'Download PDF'}
          </button>
        </div>
      </div>

      {/* Meta chips */}
      <div className="meta-chips">
        <span className="meta-chip"><Briefcase size={13} /> {session.jobRole}</span>
        <span className="meta-chip"><Clock size={13} /> {session.experience} year{session.experience !== '1' ? 's' : ''} experience</span>
        <span className="meta-chip"><Code2 size={13} /> {session.skills}</span>
        {session.resumeFile && <span className="meta-chip"><FileText size={13} /> Resume uploaded</span>}
      </div>

      {/* Questions */}
      <div className="result-section">
        <div className="result-section-title">
          <FileText size={17} /> Interview Questions &amp; Model Answers
        </div>
        <div className="question-list">
          {(session.questions || []).map((q, i) => (
            <QuestionCard key={i} q={q} index={i} />
          ))}
        </div>
      </div>

      {/* Tips */}
      <div className="result-section">
        <div className="result-section-title">
          <Lightbulb size={17} /> General Preparation Tips
        </div>
        <div className="tips-grid">
          {(session.tips || []).map((tip, i) => (
            <div key={i} className="tip-card">
              <div className="tip-num">{i + 1}</div>
              <span>{tip}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Download CTA */}
      <div style={{ textAlign: 'center', paddingTop: 20 }}>
        <button className="btn btn-ghost btn-lg" onClick={downloadPDF} disabled={downloading}>
          <Download size={18} />
          {downloading ? 'Generating PDF…' : 'Download Full Report as PDF'}
        </button>
      </div>
    </div>
  );
}
